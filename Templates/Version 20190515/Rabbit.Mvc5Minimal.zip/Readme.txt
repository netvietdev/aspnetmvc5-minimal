﻿An Optimized Starter template for ASP.NET MVC application

Rabbit MVC5 Starter Template with ready-to-use additional features such as: JQuery, Bootstrap, SimpleInjector, Log4Net structured logging extension