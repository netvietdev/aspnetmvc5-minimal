﻿This project is used to build a new template for ASP.NET MVC WebApp

Rabbit MVC5 Starter Template with ready-to-use additional features such as: JQuery, Bootstrap, SimpleInjector