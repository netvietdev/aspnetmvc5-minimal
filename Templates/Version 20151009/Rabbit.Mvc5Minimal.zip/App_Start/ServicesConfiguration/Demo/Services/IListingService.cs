﻿namespace $safeprojectname$.App_Start.ServicesConfiguration.Demo.Services
{
    public interface IListingService
    {
        int Count();
    }
}