﻿using Rabbit.IOC;
using $safeprojectname$.App_Start.ServicesConfiguration.Demo.Services;
using SimpleInjector;
using SimpleInjector.Packaging;

namespace $safeprojectname$.App_Start.ServicesConfiguration.Demo.IocModules
{
    public class DemoServicesModule : ModuleBase, IPackage
    {
        public void RegisterServices(Container container)
        {
            container.RegisterPerWebRequest<IListingService, DefaultListingService>();
        }
    }
}