﻿namespace $safeprojectname$.Models.Demo.Services
{
    public interface IListingService
    {
        int Count();
    }
}